
export const SliderData = [
    {
        image: 'https://cdn.vox-cdn.com/thumbor/euj-8za2J7I4j2PX2zkfqZZCENw=/0x42:800x492/1600x900/cdn.vox-cdn.com/uploads/chorus_image/image/50246383/DrielyS-4581.0.0.0.jpg'
    },
    {
        image: 'https://outlet-shop.co.uk/wp-content/uploads/2018/08/cropped-banner-watches-new.jpg'
    },
    {
        image: 'https://www.pixelstalk.net/wp-content/uploads/images1/Free-furniture-wallpapers.jpg'
    },
]