export * from "./DetailScreen";
