export const categories = [
  {
    name: "Shoes",
    bg: require("../../../assets/Images/bg1.jpg"),
  },
  {
    name: "Watches",
    bg: require("../../../assets/Images/bg2.jpg"),
  },
  {
    name: "Shirts",
    bg: require("../../../assets/Images/bg3.jpg"),
  },
];
