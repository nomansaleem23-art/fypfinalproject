const ProvincesData = {
  SINDH: {
    name: "Sindh",
    cities: {
      QUANBADINH: "Karachi",
      QUANHOANKIEM: "Hyderabad",
      QUANHAIBATRUNG: "Nawabshah",
      QUANDONGDA: "Tando Jam",
    },
  },
  PUNJAB: {
    name: "Punjab",
    cities: {
      QUAN1: "Quận 1",
      QUAN2: "Quận 2",
      QUAN3: "Quận 3",
    },
  },
  BALOCHISTAN: {
    name: "Balochistan",
    cities: {
      QUANHONGBANG: "Quận Hồng Bàng",
      QUANLECHAN: "Quận Lê Chân",
    },
  },
  KPK: {
    name: "Khyber Paktunkha",
    cities: {
      QUANHAICHAU: "Quận Hải Châu",
      QUANTHANHKHE: "Quận Thanh Khê",
    
    },
  },
};

const provinces = Object.values(ProvincesData);

export default provinces;
