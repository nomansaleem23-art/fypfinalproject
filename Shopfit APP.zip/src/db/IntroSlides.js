//slide
const slides = [
  {
    id: 1,
    lable: "Buy lucky",
    subtitle: "Find your favorite stone",
    des:
      "Choosing a suitable stone ring brings great benefits in career, love, money",
    imageUrl: require("../assets/Images/slide1.png"),
  },
  {
    id: 2,
    lable: "Peace Bridge",
    subtitle: "Quality products",
    des:
      "Helps increase confidence, clear mind, solve problems flexibly and smoothly",
    imageUrl: require("../assets/Images/slide2.png"),
  },
  {
    id: 3,
    lable: "Bring happiness back",
    subtitle: "What are you waiting for?",
    des: "Find yourself luck and happiness at shopping ",
    imageUrl: require("../assets/Images/slide3.png"),
  },
];
export default slides;
