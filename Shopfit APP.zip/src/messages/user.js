const userMessages = {
  "user.login.success": "Welcome back",
  "user.login.require": "You need to login! No account?",
  "user.logout.sucesss": "Logout Successfully",
  "user.signup.success": "SignUp Successfully",
  "user.changePW.sucesss": "Your Password is changed",
  "user.touchid.fail": "Your device does not support this feature",
};
export default userMessages;
