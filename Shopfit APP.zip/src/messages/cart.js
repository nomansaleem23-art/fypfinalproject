const cartMessages = {
  'cart.add.success': 'Thêm vào giỏ hàng thành công',
  'cart.add.fail': 'Có lỗi khi thêm giỏ hàng',
};
export default cartMessages;
