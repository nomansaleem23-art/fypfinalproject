const orderMessages = {
  'order.add.success': 'Đặt hàng thành công',
  'order.add.fail': 'Có lỗi khi đặt hàng',
};
export default orderMessages;
